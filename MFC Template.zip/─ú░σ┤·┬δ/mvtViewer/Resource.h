//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by mvtViewer.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDS_STRING101                   101
#define IDS_FILE_VIEW                   101
#define IDS_CLASS_VIEW                  102
#define IDR_POPUP_EDIT                  119
#define ID_STATUSBAR_PANE1              120
#define ID_STATUSBAR_PANE2              121
#define IDS_STATUS_PANE1                122
#define IDS_STATUS_PANE2                123
#define IDS_TOOLBAR_STANDARD            124
#define IDS_TOOLBAR_CUSTOMIZE           125
#define ID_VIEW_CUSTOMIZE               126
#define IDR_MAINFRAME                   128
#define IDR_MAINFRAME_256               129
#define IDR_mvtViewerTYPE               130
#define ID_WINDOW_MANAGER			    131
#define ID_PROPERTIES                   135
#define ID_OPEN                         136
#define ID_OPEN_WITH                    137
#define ID_DUMMY_COMPILE                138
#define ID_CLASS_ADD_MEMBER_FUNCTION    139
#define ID_CLASS_ADD_MEMBER_VARIABLE    140
#define ID_CLASS_DEFINITION             141
#define ID_CLASS_PROPERTIES             142
#define ID_NEW_FOLDER                   143
#define ID_SORT_MENU                    144
#define ID_SORTING_GROUPBYTYPE		    145
#define ID_SORTING_SORTALPHABETIC	    146
#define ID_SORTING_SORTBYTYPE		    147
#define ID_SORTING_SORTBYACCESS		    148
#define ID_VIEW_FILEVIEW                149
#define ID_VIEW_CLASSVIEW               150
#define IDR_POPUP_EXPLORER              174
#define IDR_MENU_IMAGES				    179
#define IDB_MENU_IMAGES_24			    180
#define ID_TOOLS_MACRO				    181
#define IDS_EXPLORER				    305
#define IDS_EDIT_MENU                   306
#define IDB_CLASS_VIEW                  310
#define IDB_FILE_VIEW                   311
#define IDB_FILE_VIEW_24                312
#define IDB_CLASS_VIEW_24               313
#define IDB_EXPLORER_24                 315
#define IDR_EXPLORER                    316
#define IDR_POPUP_SORT                  317
#define IDR_SORT                        318
#define IDB_SORT_24                     320
#define IDI_CLASS_VIEW                  321
#define IDI_CLASS_VIEW_HC               322
#define IDI_FILE_VIEW                   323
#define IDI_ICON4                       324
#define IDI_FILE_VIEW_HC                324
#define ID_BUTTON32771                  32771



// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        325
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           321
#endif
#endif
